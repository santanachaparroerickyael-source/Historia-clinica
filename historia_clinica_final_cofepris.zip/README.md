# Historia Clínica Odontológica - COFEPRIS (Versión final)

Contenido:
- index.html: formulario web completo con firma digital y exportación a PDF.
- /css, /js, /assets: carpetas para recursos futuros.

Cómo publicar en GitHub Pages:
1. Crear repositorio, subir archivos (index.html y README.md).
2. Settings -> Pages -> Branch main, folder /root -> Save.
3. Esperar unos minutos y acceder a: https://TU_USUARIO.github.io/TU_REPO/

Notas:
- El PDF se nombra automáticamente con el nombre del paciente y la fecha.
- Se incluye firma digital (dibujada), que se captura en el PDF.
- Revisa y adapta el texto del consentimiento según requisitos locales.
